/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vaishu.store.dao;

/**
 *
 * @author Vaisshnavi Janani
 */
import java.sql.Connection;  
import java.sql.DriverManager;  
import java.sql.PreparedStatement;  
import java.sql.ResultSet;  
import java.sql.SQLException;  
import com.vaishu.store.java.DBConnection;
  
public class LoginDao {  
    public static boolean validate(String name, String pass) {          
        boolean status = false;  
        Connection connection = null;  
        PreparedStatement pst = null;  
        ResultSet rs = null;  
  
       /* String url = "jdbc:db2://localhost:50000/sample";  
        String jdbcClassName = "com.ibm.db2.jcc.DB2Driver";  
        String userName = "db2admin";  
        String password = "Narasimah_108";  */
          
            try {
                connection=DBConnection.connect();
            pst = connection.prepareStatement("select * from shop.user where user_id=? and user_passwd=?");  
            pst.setString(1, name);  
            pst.setString(2, pass);  
  
            rs = pst.executeQuery();  
            status = rs.next();  
  
        } catch (Exception e) {  
            System.out.println(e);  
        } finally {  
              
            if (pst != null) {  
                try {  
                    pst.close();  
                } catch (SQLException e) {  
                    e.printStackTrace();  
                }  
            }  
            if (rs != null) {  
                try {  
                    rs.close();  
                } catch (SQLException e) {  
                    e.printStackTrace();  
                }  
            }  
        }  
        return status;  
    }  
}  