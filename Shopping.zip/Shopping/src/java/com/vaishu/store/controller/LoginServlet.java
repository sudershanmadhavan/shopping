/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.vaishu.store.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.vaishu.store.dao.LoginDao;

/**
 *
 * @author Vaisshnavi Janani
 */
public class LoginServlet extends HttpServlet {    
  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String forwardUrl="";
        String message="";
        
        if(request.getParameter("username")!=null && request.getParameter("userpass")!=null)
        {
            String userName=request.getParameter("username");
            String userPass=request.getParameter("userpass");
            boolean status=LoginDao.validate(userName, userPass);
            
            if (status==true)
            {
                request.setAttribute("loginId",userName);
                forwardUrl="/welcome.jsp";
            }
            else
            {
                forwardUrl="/index.jsp";
                message="invalid credentials";
            }
        }
        else
        {
            forwardUrl="/login.jsp";
            message="kindly provide valid inputs";            
        }
        request.setAttribute("errormessage", message);
        //String option=request.getParameter("dropDown");
        
        RequestDispatcher rd=getServletContext().getRequestDispatcher(forwardUrl);    
        rd.forward(request, response);

    }
}
